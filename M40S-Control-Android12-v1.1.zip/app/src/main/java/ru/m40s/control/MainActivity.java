package ru.m40s.control;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.view.*;
import android.widget.*;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Простое прямое BLE-управление REDMOND RMC-M40S.
 * Не использует Ready for Sky, аккаунт, SMS или интернет.
 *
 * Протокол сверен с открытым проектом SkyCooker-HА:
 * кадр 55 <counter> <command> <payload> AA.
 */
public class MainActivity extends Activity {
    private static final UUID SERVICE = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID TX = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID RX = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    // Для RMC-M40S: MODEL_3, 16 байт ключа — нули.
    private static final byte[] AUTH_KEY = new byte[16];

    private static final int CMD_VERSION = 0x01;
    private static final int CMD_START = 0x03;
    private static final int CMD_STOP = 0x04;
    private static final int CMD_SET_MODE = 0x05;
    private static final int CMD_STATUS = 0x06;
    private static final int CMD_SELECT_PROGRAM = 0x09;
    private static final int CMD_AUTH = 0xFF;

    // Порядок именно для M40S. ID 15 = резерв/none, 16 = standby, 17 = vacuum.
    private final String[] programs = {
            "Мультиповар", "Молочная каша", "Тушение", "Жарка", "Суп", "Пар",
            "Паста", "Томление", "Варка", "Выпечка", "Рис/крупы", "Плов",
            "Йогурт", "Пицца", "Хлеб", "Вакуум"
    };
    private final int[] programIds = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 17};

    private BluetoothAdapter bt;
    private BluetoothLeScanner scanner;
    private ScanCallback scanCallback;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic tx;
    private BluetoothGattCharacteristic rx;
    private BluetoothGattDescriptor rxDescriptor;

    private final AtomicInteger counter = new AtomicInteger(0);
    private volatile byte[] lastReply;
    private volatile int lastReplyCounter = -1;
    private volatile boolean authenticated = false;
    private volatile boolean connecting = false;

    private TextView status;
    private TextView info;
    private Spinner prog;
    private EditText temp, hours, mins;
    private CheckBox warm;
    private Button startButton, stopButton, statusButton;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        requestBluetoothPermissions();
    }

    private TextView tv(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(16);
        t.setPadding(8, 8, 8, 8);
        return t;
    }

    private Button btn(String s) {
        Button b = new Button(this);
        b.setText(s);
        return b;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(16, 10, 16, 10);

        TextView title = tv("REDMOND RMC-M40S");
        title.setTextSize(22);
        root.addView(title);

        TextView sub = tv("Прямое управление по Bluetooth • без Ready for Sky");
        sub.setTextSize(13);
        root.addView(sub);

        status = tv("Статус: не подключено");
        root.addView(status);

        LinearLayout scanRow = new LinearLayout(this);
        scanRow.setOrientation(LinearLayout.HORIZONTAL);
        Button scan = btn("Найти M40S");
        Button disconnect = btn("Отключить");
        scanRow.addView(scan, new LinearLayout.LayoutParams(0, -2, 1));
        scanRow.addView(disconnect, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(scanRow);

        root.addView(tv("Программа:"));
        prog = new Spinner(this);
        prog.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, programs));
        root.addView(prog);

        LinearLayout values = new LinearLayout(this);
        values.setOrientation(LinearLayout.HORIZONTAL);
        temp = edit("100");
        hours = edit("0");
        mins = edit("30");
        values.addView(labeled("°C", temp), new LinearLayout.LayoutParams(0, -2, 1));
        values.addView(labeled("Часы", hours), new LinearLayout.LayoutParams(0, -2, 1));
        values.addView(labeled("Минуты", mins), new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(values);

        warm = new CheckBox(this);
        warm.setText("Автоподогрев");
        warm.setChecked(true);
        root.addView(warm);

        startButton = btn("СТАРТ");
        stopButton = btn("СТОП");
        statusButton = btn("Обновить статус");
        startButton.setEnabled(false);
        stopButton.setEnabled(false);
        statusButton.setEnabled(false);
        root.addView(startButton);
        root.addView(stopButton);
        root.addView(statusButton);

        info = tv("Температура: —\nВремя: —\nСостояние: —");
        root.addView(info);

        TextView note = tv("Важно: сначала проверяем только связь. Мультиварка должна быть рядом, Bluetooth включён, а Ready for Sky не должен быть подключён к ней. Для первого теста не запускай нагрев.");
        note.setTextSize(13);
        root.addView(note);

        setContentView(root);

        scan.setOnClickListener(v -> startScan());
        disconnect.setOnClickListener(v -> disconnect());
        startButton.setOnClickListener(v -> startCooking());
        stopButton.setOnClickListener(v -> sendSimple(CMD_STOP));
        statusButton.setOnClickListener(v -> getStatus());
    }

    private LinearLayout labeled(String label, EditText edit) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(tv(label));
        box.addView(edit);
        return box;
    }

    private EditText edit(String value) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setInputType(2);
        return e;
    }

    private boolean hasBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestBluetoothPermissions() {
        ArrayList<String> p = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)
                p.add(Manifest.permission.BLUETOOTH_SCAN);
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
                p.add(Manifest.permission.BLUETOOTH_CONNECT);
        } else if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            p.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (!p.isEmpty()) requestPermissions(p.toArray(new String[0]), 100);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == 100) {
            if (hasBluetoothPermissions()) setStatus("разрешение Bluetooth получено");
            else setStatus("нужно разрешение «Устройства поблизости»");
        }
    }

    private void setStatus(String text) {
        runOnUiThread(() -> status.setText("Статус: " + text));
    }

    private boolean initBluetooth() {
        if (!hasBluetoothPermissions()) {
            requestBluetoothPermissions();
            return false;
        }
        BluetoothManager manager = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        bt = manager.getAdapter();
        if (bt == null) {
            setStatus("Bluetooth недоступен на телефоне");
            return false;
        }
        if (!bt.isEnabled()) {
            try {
                startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));
            } catch (SecurityException e) {
                setStatus("не удалось включить Bluetooth");
            }
            return false;
        }
        return true;
    }

    private void startScan() {
        if (!initBluetooth()) return;
        stopScan();
        authenticated = false;
        scanner = bt.getBluetoothLeScanner();
        if (scanner == null) {
            setStatus("BLE-сканер недоступен");
            return;
        }

        setStatus("поиск RMC-M40S...");
        scanCallback = new ScanCallback() {
            @Override
            public void onScanResult(int callbackType, ScanResult result) {
                BluetoothDevice d = result.getDevice();
                String name = safeName(d);
                boolean nameMatch = name.toUpperCase(Locale.ROOT).contains("M40S");
                boolean serviceMatch = result.getScanRecord() != null
                        && result.getScanRecord().getServiceUuids() != null
                        && result.getScanRecord().getServiceUuids().stream().anyMatch(x -> SERVICE.equals(x.getUuid()));
                if (nameMatch || serviceMatch) {
                    stopScan();
                    connect(d);
                }
            }

            @Override
            public void onScanFailed(int errorCode) {
                setStatus("ошибка поиска BLE: " + errorCode);
            }
        };

        try {
            ScanFilter filter = new ScanFilter.Builder().setServiceUuid(new android.os.ParcelUuid(SERVICE)).build();
            ScanSettings settings = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
            scanner.startScan(Collections.singletonList(filter), settings, scanCallback);
        } catch (Exception e) {
            setStatus("не удалось начать поиск: " + e.getMessage());
            return;
        }
        handler.postDelayed(this::stopScan, 12000);
    }

    private void stopScan() {
        if (scanner != null && scanCallback != null) {
            try { scanner.stopScan(scanCallback); } catch (Exception ignored) { }
        }
        scanCallback = null;
    }

    private String safeName(BluetoothDevice d) {
        try {
            String n = d.getName();
            return n != null ? n : d.getAddress();
        } catch (Exception e) {
            return d.getAddress();
        }
    }

    private void connect(BluetoothDevice device) {
        if (connecting) return;
        connecting = true;
        authenticated = false;
        closeGattOnly();
        setStatus("подключение к " + safeName(device));
        try {
            gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
        } catch (Exception e) {
            connecting = false;
            setStatus("ошибка подключения: " + e.getMessage());
        }
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt g, int statusCode, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                gatt = g;
                connecting = false;
                setStatus("подключено, поиск службы...");
                try { g.discoverServices(); } catch (SecurityException e) { setStatus("нет разрешения Bluetooth"); }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                connecting = false;
                authenticated = false;
                enableButtons(false);
                setStatus("соединение потеряно (код " + statusCode + ")");
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt g, int statusCode) {
            if (statusCode != BluetoothGatt.GATT_SUCCESS) {
                setStatus("ошибка поиска служб: " + statusCode);
                return;
            }
            BluetoothGattService service = g.getService(SERVICE);
            if (service == null) {
                setStatus("BLE-служба M40S не найдена");
                return;
            }
            tx = service.getCharacteristic(TX);
            rx = service.getCharacteristic(RX);
            if (tx == null || rx == null) {
                setStatus("TX/RX характеристики не найдены");
                return;
            }
            try {
                boolean ok = g.setCharacteristicNotification(rx, true);
                rxDescriptor = rx.getDescriptor(CCCD);
                if (rxDescriptor != null) {
                    rxDescriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                    g.writeDescriptor(rxDescriptor);
                } else if (ok) {
                    handler.postDelayed(MainActivity.this::authenticate, 300);
                }
            } catch (Exception e) {
                setStatus("ошибка включения уведомлений: " + e.getMessage());
            }
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor descriptor, int statusCode) {
            if (CCCD.equals(descriptor.getUuid()) && statusCode == BluetoothGatt.GATT_SUCCESS) {
                handler.postDelayed(MainActivity.this::authenticate, 250);
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
            if (RX.equals(c.getUuid())) {
                acceptReply(c.getValue());
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value) {
            if (RX.equals(c.getUuid())) acceptReply(value);
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt g, BluetoothGattCharacteristic c, int statusCode) {
            if (statusCode != BluetoothGatt.GATT_SUCCESS) setStatus("ошибка записи BLE: " + statusCode);
        }
    };

    private synchronized void acceptReply(byte[] value) {
        if (value == null || value.length < 4) return;
        if ((value[0] & 0xFF) != 0x55 || (value[value.length - 1] & 0xFF) != 0xAA) return;
        int responseCounter = value[1] & 0xFF;
        if (responseCounter == counter.get()) {
            lastReply = Arrays.copyOf(value, value.length);
            lastReplyCounter = responseCounter;
        }
    }

    private byte[] command(int command, byte[] params) throws Exception {
        if (gatt == null || tx == null || !authenticated && command != CMD_AUTH) throw new Exception("нет авторизованного соединения");
        int c = counter.updateAndGet(x -> (x + 1) & 0xFF);
        byte[] payload = params == null ? new byte[0] : params;
        byte[] packet = new byte[3 + payload.length + 1];
        packet[0] = 0x55;
        packet[1] = (byte) c;
        packet[2] = (byte) command;
        System.arraycopy(payload, 0, packet, 3, payload.length);
        packet[packet.length - 1] = (byte) 0xAA;

        lastReply = null;
        lastReplyCounter = -1;
        boolean written;
        synchronized (this) {
            if (Build.VERSION.SDK_INT >= 33) {
                int writeType = (tx.getProperties() & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0
                        ? BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                        : BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE;
                int result = gatt.writeCharacteristic(tx, packet, writeType);
                written = result == BluetoothGatt.GATT_SUCCESS;
            } else {
                int writeType = (tx.getProperties() & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0
                        ? BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                        : BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE;
                tx.setWriteType(writeType);
                tx.setValue(packet);
                written = gatt.writeCharacteristic(tx);
            }
        }
        if (!written) throw new Exception("BLE write failed");

        long deadline = System.currentTimeMillis() + 1800;
        while (System.currentTimeMillis() < deadline) {
            if (lastReply != null && lastReplyCounter == c) break;
            Thread.sleep(25);
        }
        byte[] r = lastReply;
        if (r == null) throw new Exception("таймаут ответа");
        if (r.length < 4 || (r[0] & 0xFF) != 0x55 || (r[r.length - 1] & 0xFF) != 0xAA) throw new Exception("неверный пакет");
        int responseCommand = r[2] & 0xFF;
        if (responseCommand != command) {
            // После 0x03/0x05 устройство иногда отвечает статусом 0x06.
            if ((command == CMD_START || command == CMD_SET_MODE || command == CMD_SELECT_PROGRAM) && responseCommand == CMD_STATUS) {
                return new byte[]{1};
            }
            throw new Exception(String.format(Locale.US, "ответ 0x%02X вместо 0x%02X", responseCommand, command));
        }
        return Arrays.copyOfRange(r, 3, r.length - 1);
    }

    private void authenticate() {
        new Thread(() -> {
            try {
                byte[] r = command(CMD_AUTH, AUTH_KEY);
                if (r.length > 0 && (r[0] & 0xFF) != 0) {
                    authenticated = true;
                    setStatus("подключено и авторизация OK");
                    enableButtons(true);
                    getStatus();
                } else {
                    setStatus("авторизация не прошла — включи режим Bluetooth на M40S");
                }
            } catch (Exception e) {
                setStatus("авторизация: " + e.getMessage());
            }
        }).start();
    }

    private void startCooking() {
        new Thread(() -> {
            try {
                int pid = programIds[prog.getSelectedItemPosition()];
                int t = clamp(parse(temp, 100), 0, 200);
                int hh = clamp(parse(hours, 0), 0, 23);
                int mm = clamp(parse(mins, 30), 0, 59);

                // M40S = MODEL_3: SET_MAIN_MODE всегда ровно 8 байт.
                byte[] data = {
                        (byte) pid, 0, (byte) t, (byte) hh, (byte) mm,
                        0, 0, (byte) (warm.isChecked() ? 1 : 0)
                };

                // Для MODEL_3 команда 0x09 принимает только ID программы.
                command(CMD_SELECT_PROGRAM, new byte[]{(byte) pid});
                Thread.sleep(120);
                command(CMD_SET_MODE, data);
                Thread.sleep(120);
                byte[] r = command(CMD_START, new byte[0]);
                setStatus(r.length > 0 && (r[0] & 0xFF) == 1 ? "готовка запущена" : "команда СТАРТ отправлена");
                getStatus();
            } catch (Exception e) {
                setStatus("СТАРТ: " + e.getMessage());
            }
        }).start();
    }

    private int parse(EditText e, int def) {
        try { return Integer.parseInt(e.getText().toString().trim()); }
        catch (Exception ex) { return def; }
    }

    private int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }

    private void sendSimple(int cmd) {
        new Thread(() -> {
            try {
                command(cmd, new byte[0]);
                setStatus(cmd == CMD_STOP ? "остановлено" : "OK");
                getStatus();
            } catch (Exception e) {
                setStatus("команда: " + e.getMessage());
            }
        }).start();
    }

    private void getStatus() {
        new Thread(() -> {
            try {
                byte[] r = command(CMD_STATUS, new byte[0]);
                if (r.length < 16) throw new Exception("статус содержит " + r.length + " байт, нужно 16");
                int pid = r[0] & 0xFF;
                int tempNow = r[2] & 0xFF;
                int hh = r[3] & 0xFF;
                int mm = r[4] & 0xFF;
                int state = r[8] & 0xFF;
                String[] states = {
                        "выключена", "ожидание", "отложенный старт", "разогрев",
                        "ожидание продуктов", "готовка", "автоподогрев", "ошибка",
                        "ожидание подтверждения", "остановка"
                };
                String stateText = state < states.length ? states[state] : "неизвестно (" + state + ")";
                runOnUiThread(() -> info.setText(
                        "Температура: " + tempNow + " °C\n" +
                        "Время: " + hh + ":" + String.format(Locale.US, "%02d", mm) + "\n" +
                        "Состояние: " + stateText + "\n" +
                        "Программа ID: " + pid));
            } catch (Exception e) {
                setStatus("статус: " + e.getMessage());
            }
        }).start();
    }

    private void enableButtons(boolean enabled) {
        runOnUiThread(() -> {
            startButton.setEnabled(enabled);
            stopButton.setEnabled(enabled);
            statusButton.setEnabled(enabled);
        });
    }

    private void disconnect() {
        stopScan();
        authenticated = false;
        enableButtons(false);
        closeGattOnly();
        setStatus("отключено");
    }

    private void closeGattOnly() {
        try { if (gatt != null) gatt.disconnect(); } catch (Exception ignored) { }
        try { if (gatt != null) gatt.close(); } catch (Exception ignored) { }
        gatt = null;
        tx = null;
        rx = null;
        rxDescriptor = null;
    }

    @Override
    protected void onDestroy() {
        stopScan();
        closeGattOnly();
        super.onDestroy();
    }
}
